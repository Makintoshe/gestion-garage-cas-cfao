/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.Facturepiece;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Ketsia
 */
public class FacturepieceDao extends Modele<Facturepiece> {

    private static PreparedStatement ps = null;
    private static Connection connectObject = ConnexionBD.ObtenirConnexion();

    @Override
    public int Ajouter(Facturepiece obj) {
        String req = "INSERT INTO `faturepiece`(`idCl`, `codePiece`, `qte`, `PT`, `dateVentep`) VALUES (?,?,?,?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setInt(1, obj.getIdClient().getIdCl());
            ps.setString(2, obj.getCodePiece().getCodePiece());
            ps.setInt(3, obj.getQte());
            ps.setDouble(4, obj.getPrT());
            ps.setDate(5, Date.valueOf(obj.getDateVentep()));
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

        return 0;
    }

    @Override
    public int Modifier(Facturepiece obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int Supprimer(Facturepiece id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Facturepiece> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void RemplirTable(JTable jTabF) {
        try {
            String req = "SELECT `client`.`nomCl` AS `Nom` ,`client`.`prenomCl` AS `Prenom`,`client`.`Tel` AS `Contact`,`piecerechange`.`desinationPiece` AS `Piece`,`piecerechange`.`CodePiece` AS `Code`,`piecerechange`.`prixU` AS `PU`,`faturepiece`.`qte` AS `Quantite`,`faturepiece`.`PT` AS `PT`,`faturepiece`.`dateVentep` AS `Date`FROM `client`,`faturepiece`,`piecerechange` WHERE `faturepiece`.`idCl`=`client`.`idCl` AND `faturepiece`.`codePiece`=`piecerechange`.`CodePiece`";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabF.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }

}
