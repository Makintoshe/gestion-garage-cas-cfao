/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.Automobile;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Ketsia
 */
public class AutomobileDao extends Modele<Automobile> {

    @Override
    public int Ajouter(Automobile obj) {
      String req = "INSERT INTO `automobile`(`immatriculation`, `designation`, `marque`, `idTypAuto`) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, obj.getImmatriculation());
            ps.setString(2, obj.getDesignation());
            ps.setString(3, obj.getMarque());
            ps.setInt(4, obj.getIdTypeAutoA().getIdTypeAuto());
            //
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        } 
        
        return 0;
   }

    @Override
    public int Modifier(Automobile obj) {
      String req = "UPDATE `automobile` SET `immatriculation`=?,`designation`=?,`marque`=?,`idTypAuto`=? WHERE `immatriculation`=?";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, obj.getImmatriculation());
            ps.setString(2, obj.getDesignation());
            ps.setString(3, obj.getMarque());
            ps.setInt(4, obj.getIdTypeAutoA().getIdTypeAuto());
            ps.setString(5, obj.getImmatriculation());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Modification:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        } 
        return 0;
        
    }

    @Override
    public int Supprimer(Automobile id) {
      String req = "DELETE FROM `automobile` WHERE `immatriculation`=?";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, id.getImmatriculation());
            
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Suppression:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        } 
        return 0;
    }

    @Override
    public List<Automobile> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
