/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.Reparation;
import java.awt.HeadlessException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Laurel
 */
public class ReparationDao extends Modele<Reparation> {

    @Override
    public int Ajouter(Reparation obj) {
        String req = "INSERT INTO `reparation`(`immatriculation`, `idMecano`) VALUES (?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, obj.getImmatriculation().getImmatriculation());
            ps.setInt(2, obj.getIdMecanoR().getIdMecano());
            System.out.println("Rep"+obj.getImmatriculation().getImmatriculation()+"et"+obj.getIdMecanoR().getIdMecano());
            //
        
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }
        return 0;
    }

    @Override
    public int Modifier(Reparation obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int Supprimer(Reparation id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Reparation> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
