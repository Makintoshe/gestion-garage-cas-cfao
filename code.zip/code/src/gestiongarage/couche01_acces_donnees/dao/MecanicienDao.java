/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.Mecanicien;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Laurel
 */
public class MecanicienDao extends Modele<Mecanicien>{
    private static PreparedStatement ps = null;
    private static Connection connectObject = ConnexionBD.ObtenirConnexion();

    @Override
    public int Ajouter(Mecanicien obj) {
     String req="INSERT INTO `mecanicien`(`nomMec`, `prenomMec`, `telMec`, `adress`) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps=connectObject.prepareStatement(req);
            ps.setString(1, obj.getNomMec());
            ps.setString(2, obj.getPrenomMec());
            ps.setInt(3, obj.getTelMec());
            ps.setString(4, obj.getAdress());
           //
           JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
       JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);
        }
     
     return 0;
    }

    @Override
    public int Modifier(Mecanicien obj) {
       String req="UPDATE `mecanicien` SET `nomMec`=?,`prenomMec`=?,`telMec`=?,`adress`=? WHERE `idMecano`=?";
        try {
            PreparedStatement ps=connectObject.prepareStatement(req);
            ps.setString(1, obj.getNomMec());
            ps.setString(2, obj.getPrenomMec());
            ps.setInt(3, obj.getTelMec());
            ps.setString(4, obj.getAdress());
            ps.setInt(5, obj.getIdMecano());
           //
           JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
       JOptionPane.showMessageDialog(null, "Modification:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);
        }
        
        return 0;
      }

    @Override
    public int Supprimer(Mecanicien id) {
        String req="DELETE FROM `mecanicien` WHERE `idMecano`=?";
        try {
            PreparedStatement ps=connectObject.prepareStatement(req);
            ps.setInt(1, id.getIdMecano());
           //
           JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
       JOptionPane.showMessageDialog(null, "Suppression:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);
        }
        return 0;
       }

    @Override
    public List<Mecanicien> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public static void RemplirTable(JTable jTabMecano) {
        try {
            String req = "SELECT `idMecano` As `N°`, `nomMec` As `Nom`, `prenomMec` As `Prenom`, `telMec` As `Contact`, `adress` As `Adresse` FROM `mecanicien`";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabMecano.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }
    public static void RemplirTablR(JTable jTabMecanoR) {
        try {
            String req = "SELECT `mecanicien`.`nomMec` As `NOM`,`mecanicien`.`prenomMec` AS `PRENOM`,`mecanicien`.`telMec`AS `CONTACT`,`automobile`.`immatriculation` AS `PLAQUE`FROM `reparation`,`mecanicien`,`automobile`WHERE `reparation`.`immatriculation`=`automobile`.`immatriculation`AND `reparation`.`idMecano`=`mecanicien`.`idMecano`AND`reparation`.`immatriculation`=`automobile`.`immatriculation`";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabMecanoR.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }
}
