/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import java.sql.Connection;
import java.util.List;

/**
 *
 * @author Laurel
 */
public abstract class Modele<T> {
    protected Connection connectObject= ConnexionBD.ObtenirConnexion();
    public abstract int Ajouter(T obj);
    public abstract int Modifier(T obj);
    public abstract int Supprimer(T id);
    public abstract List<T> Rechercher();
}
