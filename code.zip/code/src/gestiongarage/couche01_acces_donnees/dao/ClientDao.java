/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.Client;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Ketsia
 */
public class ClientDao extends Modele<Client> {

    private static PreparedStatement ps = null;
    private static Connection connectObject = ConnexionBD.ObtenirConnexion();

    @Override
    public int Ajouter(Client obj) {
        String req = "INSERT INTO `client`( `nomCl`, `prenomCl`, `Tel`) VALUES (?,?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, obj.getNomCl());
            ps.setString(2, obj.getPrenomCl());
            ps.setInt(3, obj.getTel());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

        return 0;
    }

    @Override
    public int Modifier(Client obj) {
        String req = "UPDATE `client` SET `nomCl`=?,`prenomCl`=?,`Tel`=? WHERE `idCl`=?";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(1, obj.getNomCl());
            ps.setString(2, obj.getPrenomCl());
            ps.setInt(3, obj.getTel());
            ps.setInt(4, obj.getIdCl());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Modification:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

        return 0;
    }

    @Override
    public int Supprimer(Client id) {
        String req = "DELETE FROM `client` WHERE `idCl`=?";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setInt(1, id.getIdCl());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Suppression:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }
        return 0;
    }

    @Override
    public List<Client> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void RemplirTable(JTable jTabCl) {
        try {
            String req = "SELECT `idCl` AS `N°`, `nomCl` As `Nom`, `prenomCl` As `Prenom`, `Tel` AS `Contact` FROM `client`";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabCl.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }
}
