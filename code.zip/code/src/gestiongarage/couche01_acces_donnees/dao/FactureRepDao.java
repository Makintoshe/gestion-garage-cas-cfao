/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.FactureRep;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Ketsia
 */
public class FactureRepDao extends Modele<FactureRep> {

    private static PreparedStatement ps = null;
    private static Connection connectObject = ConnexionBD.ObtenirConnexion();

    @Override
    public int Ajouter(FactureRep obj) {
        String req = "INSERT INTO `facturerep`(`idCl`, `immatriculation`, `motif`, `tarif`) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setInt(1, obj.getIdClF().getIdCl());
            ps.setString(2, obj.getImmatriculation().getImmatriculation());
            ps.setString(3, obj.getMotif());
            ps.setString(4, obj.getTarif());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Facturation:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }
        return 0;
    }

    @Override

    public int Modifier(FactureRep obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int Supprimer(FactureRep id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<FactureRep> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void RemplirTable(JTable jTabF) {
        try {
            String req = "SELECT `client`.`nomCl` As `Nom`,`client`.`prenomCl`AS`Prenom`,`client`.`Tel`AS `Contact`, `automobile`.`designation`As `Automobile`,`type_automobile`.`designation` AS `Type auto`,`automobile`.`immatriculation`AS `Plaque`,`facturerep`.`motif` AS`Motif`,`facturerep`.`tarif`AS`Tarif` FROM `client`,`automobile`,`facturerep`,`type_automobile` WHERE `facturerep`.`idCl`=`client`.`idCl` AND `facturerep`.`immatriculation`=`automobile`.`immatriculation`AND `type_automobile`.`idTypAuto`=`automobile`.`idTypAuto`";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabF.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }
}
