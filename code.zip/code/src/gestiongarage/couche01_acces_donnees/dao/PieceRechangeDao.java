/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.dao;

import gestiongarage.couche01_acces_donnees.entite.PieceRechange;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Laurel
 */
public class PieceRechangeDao extends Modele<PieceRechange> {
 private static PreparedStatement ps = null;
    private static Connection connectObject = ConnexionBD.ObtenirConnexion();
    @Override
    public int Ajouter(PieceRechange obj) {
       String req = "INSERT INTO `piecerechange`(`CodePiece`,`desinationPiece`, `idCat`, `prixU`) VALUES (?,?,?,?)";
        try {
            PreparedStatement ps = connectObject.prepareStatement(req);
            ps.setString(2, obj.getDesignationPiece());
            ps.setInt(3, obj.getIdCat().getIdCat());
            ps.setDouble(4, obj.getPrixU());
            ps.setString(1, obj.getCodePiece());
            //
            JOptionPane.showMessageDialog(null, "Succes", "ACTION", JOptionPane.INFORMATION_MESSAGE);
            return ps.executeUpdate();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Ajout:  " + e.getMessage(), "BD ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

        return 0;
    
    }

    @Override
    public int Modifier(PieceRechange obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int Supprimer(PieceRechange id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<PieceRechange> Rechercher() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public static void RemplirTable(JTable jTabPiec) {
        try {
            String req = "SELECT `CodePiece` As `Code`, `desinationPiece` As `Piece`,`prixU`AS `PU`, `idCat` As `Categorie` FROM `piecerechange` ";
            ps = connectObject.prepareStatement(req);
            ResultSet rs = ps.executeQuery();
            jTabPiec.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException e) {
        }
    }
}
