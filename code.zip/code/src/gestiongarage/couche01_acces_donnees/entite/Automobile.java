/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

/**
 *
 * @author Ketsia
 */
public class Automobile {
    private String immatriculation;
    private String designation;
    private String marque;
    private Type_automobile idTypeAutoA;

    public Automobile() {
    }

    public Automobile(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    public String getImmatriculation() {
        return immatriculation;
    }

    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public Type_automobile getIdTypeAutoA() {
        return idTypeAutoA;
    }

    public void setIdTypeAutoA(Type_automobile idTypeAutoA) {
        this.idTypeAutoA = idTypeAutoA;
    }
    
}
