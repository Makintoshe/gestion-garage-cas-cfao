/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

/**
 *
 * @author Ketsia
 */
public class FactureRep {
    private Client idClF;
    private Automobile immatriculation;
    private String motif;
    private String tarif;

    public FactureRep() {
    }

    public Client getIdClF() {
        return idClF;
    }

    public void setIdClF(Client idClF) {
        this.idClF = idClF;
    }

    public Automobile getImmatriculation() {
        return immatriculation;
    }

    public void setImmatriculation(Automobile immatriculation) {
        this.immatriculation = immatriculation;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getTarif() {
        return tarif;
    }

    public void setTarif(String tarif) {
        this.tarif = tarif;
    }
    
}
