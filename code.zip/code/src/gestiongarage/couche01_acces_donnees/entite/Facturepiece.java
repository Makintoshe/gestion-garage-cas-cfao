/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

import java.time.LocalDate;

/**
 *
 * @author Ketsia
 */
public class Facturepiece {
    private Client idClient;
    private PieceRechange codePiece;
    private int qte;
    private double prT;
    private LocalDate dateVentep;

    public Facturepiece() {
    }

    public Client getIdClient() {
        return idClient;
    }

    public void setIdClient(Client idClient) {
        this.idClient = idClient;
    }

    public PieceRechange getCodePiece() {
        return codePiece;
    }

    public void setCodePiece(PieceRechange codePiece) {
        this.codePiece = codePiece;
    }

    public int getQte() {
        return qte;
    }

    public void setQte(int qte) {
        this.qte = qte;
    }

    public double getPrT() {
        return prT;
    }

    public void setPrT(double prT) {
        this.prT = prT;
    }

    public LocalDate getDateVentep() {
        return dateVentep;
    }

    public void setDateVentep(LocalDate dateVentep) {
        this.dateVentep = dateVentep;
    }
    
    
}
