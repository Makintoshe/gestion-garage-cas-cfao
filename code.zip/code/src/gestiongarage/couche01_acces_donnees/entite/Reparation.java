/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

/**
 *
 * @author Laurel
 */
public class Reparation {

    private Automobile immatriculation;
    private Mecanicien idMecanoR;

    public Reparation() {
    }

    public Automobile getImmatriculation() {
        return immatriculation;
    }

    public void setImmatriculation(Automobile immatriculation) {
        this.immatriculation = immatriculation;
    }

    public Mecanicien getIdMecanoR() {
        return idMecanoR;
    }

    public void setIdMecanoR(Mecanicien idMecanoR) {
        this.idMecanoR = idMecanoR;
    }

}
