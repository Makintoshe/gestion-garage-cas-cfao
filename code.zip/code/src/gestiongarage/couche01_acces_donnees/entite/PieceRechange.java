/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

import gestiongarage.couche01_acces_donnees.entite.Categorie;

/**
 *
 * @author Laurel
 */
public class PieceRechange {
    private String codePiece;
    private String designationPiece;
    private double prixU;
    private Categorie idCat;

    public PieceRechange() {
    }

    public PieceRechange(String codePiece) {
        this.codePiece = codePiece;
    }

    public String getCodePiece() {
        return codePiece;
    }

    public void setCodePiece(String codePiece) {
        this.codePiece = codePiece;
    }

    public String getDesignationPiece() {
        return designationPiece;
    }

    public void setDesignationPiece(String designationPiece) {
        this.designationPiece = designationPiece;
    }

    public double getPrixU() {
        return prixU;
    }

    public void setPrixU(double prixU) {
        this.prixU = prixU;
    }

    public Categorie getIdCat() {
        return idCat;
    }

    public void setIdCat(Categorie idCat) {
        this.idCat = idCat;
    }
    
    
}
