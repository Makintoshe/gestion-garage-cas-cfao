/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

/**
 *
 * @author Ketsia
 */
public class Client {
    private int idCl;
    private String nomCl;
    private String prenomCl;
    private int tel;

    public Client() {
    }

    public Client(int idCl) {
        this.idCl = idCl;
    }

    public int getIdCl() {
        return idCl;
    }

    public void setIdCl(int idCl) {
        this.idCl = idCl;
    }

    public String getNomCl() {
        return nomCl;
    }

    public void setNomCl(String nomCl) {
        this.nomCl = nomCl;
    }

    public String getPrenomCl() {
        return prenomCl;
    }

    public void setPrenomCl(String prenomCl) {
        this.prenomCl = prenomCl;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }
    
}
