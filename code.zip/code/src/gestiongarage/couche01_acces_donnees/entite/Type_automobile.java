/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche01_acces_donnees.entite;

/**
 *
 * @author Laurel
 */
public class Type_automobile {

    private int idTypeAuto;
    private String designation;

    public Type_automobile() {
    }

    public Type_automobile(int idTypeAuto) {
        this.idTypeAuto = idTypeAuto;
    }

    public int getIdTypeAuto() {
        return idTypeAuto;
    }

    public void setIdTypeAuto(int idTypeAuto) {
        this.idTypeAuto = idTypeAuto;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

}
