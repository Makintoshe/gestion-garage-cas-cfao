/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche03_presentation.gui_controller;

import gestiongarage.couche01_acces_donnees.dao.CategorieDao;
import gestiongarage.couche01_acces_donnees.dao.ClientDao;
import gestiongarage.couche01_acces_donnees.dao.FacturepieceDao;
import gestiongarage.couche01_acces_donnees.dao.PieceRechangeDao;
import gestiongarage.couche01_acces_donnees.entite.Categorie;
import gestiongarage.couche01_acces_donnees.entite.Client;
import gestiongarage.couche01_acces_donnees.entite.PieceRechange;
import gestiongarage.couche02.service.CategorieService;
import gestiongarage.couche02.service.FacturepieceService;
import gestiongarage.couche02.service.PieceRechangeService;
import javax.swing.*;

/**
 *
 * @author Laurel
 */
public class GuiVentePieceController {
    
    public static void NouveauTyp(JTextField jTfDesignationType, JTable jTabCatp) {
        try {
            CategorieService.AjouterCat(jTfDesignationType.getText());
            CategorieDao.RemplirTable(jTabCatp);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);
            
        }
    }
    
    public static void NouvellePiece(JTable jTabPiec, JTextField jTfCode, JTextField jTfPiece, JTextField jTfPu, JTextField jTfidCat) {
        double prixU = Double.parseDouble(jTfPu.getText());
        int idCatS = Integer.parseInt(jTfidCat.getText());
        
        Categorie idCat = new Categorie(idCatS);
        PieceRechangeService.AjouterPiece(jTfCode.getText(), jTfPiece.getText(), prixU, idCat);
        PieceRechangeDao.RemplirTable(jTabPiec);
        
    }
    
    public static void facturerpier(JTable jTbpiecefac, JTextField jTfPT,JTable jTbF) {
        
        String codep = jTbpiecefac.getValueAt(0, 3).toString();
        String idCl = jTbpiecefac.getValueAt(0, 0).toString();
        String qte = jTbpiecefac.getValueAt(0, 6).toString();
        int qtep = Integer.parseInt(qte);
        String prU = jTbpiecefac.getValueAt(0, 5).toString();
        double prUd = Double.parseDouble(prU);
        //
        jTfPT.setText(String.valueOf(prUd * qtep));
        //
        double prT = Double.parseDouble(jTfPT.getText());
        //

        //
        PieceRechange codePiece = new PieceRechange(codep);
        Client idClient = new Client(qtep);
        //
        FacturepieceService.AjouterF(codePiece, idClient, prT, qtep);
        FacturepieceDao.RemplirTable(jTbF);
    }

    public static void Afficherlestab(JTable jTabPiec, JTable jTbclient, JTable jTabCatp,JTable jTbF) {
        CategorieDao.RemplirTable(jTabCatp);
        ClientDao.RemplirTable(jTbclient);
        PieceRechangeDao.RemplirTable(jTabPiec);
        FacturepieceDao.RemplirTable(jTbF);
    }
    
}
