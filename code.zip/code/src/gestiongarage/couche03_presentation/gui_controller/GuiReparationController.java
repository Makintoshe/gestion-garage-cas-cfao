/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche03_presentation.gui_controller;

import gestiongarage.couche01_acces_donnees.dao.ClientDao;
import gestiongarage.couche01_acces_donnees.dao.FactureRepDao;
import gestiongarage.couche01_acces_donnees.dao.MecanicienDao;
import gestiongarage.couche01_acces_donnees.dao.Type_AutomobileDao;
import gestiongarage.couche01_acces_donnees.entite.Automobile;
import gestiongarage.couche01_acces_donnees.entite.Client;
import gestiongarage.couche01_acces_donnees.entite.Mecanicien;
import gestiongarage.couche01_acces_donnees.entite.Type_automobile;
import gestiongarage.couche02.service.AutomobileService;
import gestiongarage.couche02.service.ClientService;
import gestiongarage.couche02.service.FactureRepService;
import gestiongarage.couche02.service.MecanicienService;
import gestiongarage.couche02.service.ReparationService;
import gestiongarage.couche02.service.Type_autoService;
import javax.swing.*;

/**
 *
 * @author Ketsia
 */
public class GuiReparationController {

    public static void insertiontables(JTable jTbautoClient, JTable jTabtypAuto, JTable jTbclient, JTable jTabMecano,JTable jTabMecanoR,JTable jTabF, JTextArea jTaMotif, JTextField jTfTarif) {
        try {
            String immatricul = jTbautoClient.getValueAt(0, 0).toString();
            String designation = jTbautoClient.getValueAt(0, 1).toString();
            String marque = jTbautoClient.getValueAt(0, 2).toString();
            String idtyp = jTbautoClient.getValueAt(0, 3).toString();
            String idMeca = jTbautoClient.getValueAt(0, 4).toString();
            String idClt = jTbautoClient.getValueAt(0, 5).toString();
            int idtypeAuto = Integer.parseInt(idtyp);
            int idMecano = Integer.parseInt(idMeca);
            int idClient = Integer.parseInt(idClt);

            Type_automobile idTypeAuto = new Type_automobile(idtypeAuto);
            Mecanicien idMec = new Mecanicien(idMecano);
            Automobile immatr = new Automobile(immatricul);
            Client idCl = new Client(idClient);

            AutomobileService.AjouterAuto(immatricul, designation, marque, idTypeAuto);
            ReparationService.AjouterRep(immatr, idMec);
            FactureRepService.AjouterFact(idCl, immatr, jTaMotif.getText(), jTfTarif.getText());
            FactureRepDao.RemplirTable(jTabF);
            MecanicienDao.RemplirTablR(jTabMecanoR);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

    }
    public static void ModifCli(JTable jTbclient) {
        try {
            String numer=jTbclient.getValueAt(jTbclient.getSelectedRow(), 0).toString();
            String nom=jTbclient.getValueAt(jTbclient.getSelectedRow(), 1).toString();
            String pren=jTbclient.getValueAt(jTbclient.getSelectedRow(), 2).toString();
            String tels=jTbclient.getValueAt(jTbclient.getSelectedRow(), 3).toString();
            //
            int idClient=Integer.parseInt(numer);
            int tel=Integer.parseInt(tels);
            ClientService.changeClient(idClient, nom, pren, tel);
            ClientDao.RemplirTable(jTbclient);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

    }
     public static void SuppCli(JTable jTbclient) {
        try {
            String numer=jTbclient.getValueAt(jTbclient.getSelectedRow(), 0).toString();
            //
            int idClient=Integer.parseInt(numer);
            ClientService.suppClient(idClient);
            ClientDao.RemplirTable(jTbclient);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

    }

    public static void NouveauMec(JTextField jTfNomMec, JTextField jTfPreMec, JTextField jTfTelMec, JTextField jTfAdressMec, JTable jTablMecano) {
        try {
            MecanicienService.AjouterMecano(jTfNomMec.getText(), jTfPreMec.getText(), Integer.parseInt(jTfTelMec.getText()), jTfAdressMec.getText());
            MecanicienDao.RemplirTable(jTablMecano);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

    }

    public static void NouveauTyp(JTextField jTfDesignationType, JTable jTabtypAuto) {
        try {
            Type_autoService.AjouterType(jTfDesignationType.getText());
            Type_AutomobileDao.RemplirTable(jTabtypAuto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Enregistrement: " + e.getMessage(), "ACTION FAILED", JOptionPane.ERROR_MESSAGE);

        }

    }

    public static void NouveauClient(JTable jTbclient) {
        String nomCl = JOptionPane.showInputDialog("NOM DU NOUVEAU CLIENT");
        String prenomCl = JOptionPane.showInputDialog("PRENOM DU NOUVEAU CLIENT");
        int tel = Integer.parseInt(JOptionPane.showInputDialog("CONTACT DU NOUVEAU CLIENT"));
        ClientService.ajouterClient(nomCl, prenomCl, tel);
        ClientDao.RemplirTable(jTbclient);
    }

    public static void Afficherlestab(JTable jTabtypAuto, JTable jTbclient, JTable jTablMecano,JTable jTabF,JTable jTabMecanoR) {
        MecanicienDao.RemplirTable(jTablMecano);
        ClientDao.RemplirTable(jTbclient);
        Type_AutomobileDao.RemplirTable(jTabtypAuto);
         FactureRepDao.RemplirTable(jTabF);
         MecanicienDao.RemplirTablR(jTabMecanoR);
    }
}
