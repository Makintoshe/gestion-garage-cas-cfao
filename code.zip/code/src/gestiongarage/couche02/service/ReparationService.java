/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.ReparationDao;
import gestiongarage.couche01_acces_donnees.entite.Automobile;
import gestiongarage.couche01_acces_donnees.entite.Mecanicien;
import gestiongarage.couche01_acces_donnees.entite.Reparation;

/**
 *
 * @author Laurel
 */
public class ReparationService {
   private static ReparationDao repDao=new ReparationDao();
   private static Reparation repX=new Reparation();
   public static int AjouterRep(Automobile immatricul,Mecanicien idMecano){
      repX.setIdMecanoR(idMecano);
      repX.setImmatriculation(immatricul);
      return repDao.Ajouter(repX);
   }
}
