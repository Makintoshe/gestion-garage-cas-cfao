/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.MecanicienDao;
import gestiongarage.couche01_acces_donnees.entite.Mecanicien;

/**
 *
 * @author Laurel
 */
public class MecanicienService {

    private static MecanicienDao mecaDao = new MecanicienDao();
    private static Mecanicien mecanoX = new Mecanicien();

    public static int AjouterMecano(String nomMec, String prenomMec, int telMec, String adresse) {
        mecanoX.setNomMec(nomMec);
        mecanoX.setPrenomMec(prenomMec);
        mecanoX.setTelMec(telMec);
        mecanoX.setAdress(adresse);
        return mecaDao.Ajouter(mecanoX);
    }
}
