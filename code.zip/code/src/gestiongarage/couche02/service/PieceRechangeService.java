/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.PieceRechangeDao;
import gestiongarage.couche01_acces_donnees.entite.Categorie;
import gestiongarage.couche01_acces_donnees.entite.PieceRechange;

/**
 *
 * @author Laurel
 */
public class PieceRechangeService {
    private static PieceRechangeDao piecRDao=new PieceRechangeDao();
    private static PieceRechange pieceX=new PieceRechange();
    public static int AjouterPiece(String codePiece,String designationPiec,double prixU,Categorie idCat){
        pieceX.setCodePiece(codePiece);
        pieceX.setDesignationPiece(designationPiec);
        pieceX.setPrixU(prixU);
        pieceX.setIdCat(idCat);
        return piecRDao.Ajouter(pieceX);
    }
}
