/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.AutomobileDao;
import gestiongarage.couche01_acces_donnees.entite.Automobile;
import gestiongarage.couche01_acces_donnees.entite.Type_automobile;

/**
 *
 * @author Ketsia
 */
public class AutomobileService {
  private static AutomobileDao autDao =new AutomobileDao();  
  private static Automobile autX=new Automobile();
  public static int AjouterAuto(String Immatricul,String Designation,String Marque,Type_automobile idTypeAuto){
   autX.setImmatriculation(Immatricul);
   autX.setDesignation(Designation);
   autX.setMarque(Marque);
   autX.setIdTypeAutoA(idTypeAuto);
   return autDao.Ajouter(autX);
  }
}
