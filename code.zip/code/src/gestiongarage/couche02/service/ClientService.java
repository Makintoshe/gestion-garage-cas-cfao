/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.ClientDao;
import gestiongarage.couche01_acces_donnees.entite.Client;

/**
 *
 * @author Ketsia
 */
public class ClientService {

    private static ClientDao clDao = new ClientDao();
    private static Client clX = new Client();

    public static int ajouterClient(String nomCl, String prenomCl, int tel) {
        clX.setNomCl(nomCl);
        clX.setPrenomCl(prenomCl);
        clX.setTel(tel);
        return clDao.Ajouter(clX);
    }
     public static int changeClient(int idclient,String nomCl, String prenomCl, int tel) {
        clX.setIdCl(idclient);
        clX.setNomCl(nomCl);
        clX.setPrenomCl(prenomCl);
        clX.setTel(tel);
        return clDao.Modifier(clX);
    }
     public static int suppClient(int idclient) {
        clX.setIdCl(idclient);
        
        return clDao.Supprimer(clX);
    }
}
