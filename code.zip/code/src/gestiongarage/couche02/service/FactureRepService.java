/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.FactureRepDao;
import gestiongarage.couche01_acces_donnees.entite.Automobile;
import gestiongarage.couche01_acces_donnees.entite.Client;
import gestiongarage.couche01_acces_donnees.entite.FactureRep;

/**
 *
 * @author Ketsia
 */
public class FactureRepService {
   private static FactureRepDao factRDAo=new FactureRepDao();
   private static FactureRep factRX=new FactureRep();
   public static int AjouterFact(Client idCl,Automobile immatricul,String motif,String tarif){
     factRX.setIdClF(idCl);
     factRX.setImmatriculation(immatricul);
     factRX.setMotif(motif);
     factRX.setTarif(tarif);
       return factRDAo.Ajouter(factRX);
       
   }
}
