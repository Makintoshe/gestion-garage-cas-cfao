/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.CategorieDao;
import gestiongarage.couche01_acces_donnees.entite.Categorie;

/**
 *
 * @author Ketsia
 */
public class CategorieService {

    private static CategorieDao catDao = new CategorieDao();
    private static Categorie catX = new Categorie();

    public static int AjouterCat(String libell) {
        catX.setLibell(libell);
        return catDao.Ajouter(catX);
    }
}
