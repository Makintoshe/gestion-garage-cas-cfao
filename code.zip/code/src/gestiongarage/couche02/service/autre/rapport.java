/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service.autre;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.DateFormat;
import javax.swing.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;


/**
 *
 * @author Laurel
 */
public class rapport {
     public static void rap(JTable tablP,JTable tablC,JTextField jTextTotal,int Qte){
     Document document=new Document();
        Date aujourdhui=new Date();
      DateFormat shortDateFormat=DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT);
      String Tdy=shortDateFormat.format(aujourdhui);
        
     try {
            
        PdfWriter.getInstance(document,new FileOutputStream("Facture.pdf"));
        document.open();
        document.add(new Paragraph(" "));
        document.add(new Paragraph("                        Facture                          "+"              Date: "+Tdy));
       document.add(new Paragraph(" "));
       ///
       document.add(new Paragraph(" "));
        document.add(new Paragraph("PRODUIT(S)"));
       document.add(new Paragraph(" "));
       ///
       PdfPTable tableP=new PdfPTable(3);
       tableP.setWidthPercentage(100);
         PdfPCell cell;
         ///////////////////////////////////////////////////////////////////////
         cell=new PdfPCell(new Phrase("Code Produit",FontFactory.getFont("Georgia",12)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setBackgroundColor(Color.GRAY);
         tableP.addCell(cell);
         
         cell=new PdfPCell(new Phrase("Designation",FontFactory.getFont("Georgia",12)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setBackgroundColor(Color.GRAY);
         tableP.addCell(cell);
         
         cell=new PdfPCell(new Phrase("Prix",FontFactory.getFont("Georgia",12)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
         cell.setBackgroundColor(Color.GRAY);
         tableP.addCell(cell);
         ///////
         String a,b,c;
        for (int i = 0; i < Qte; i++) {
            a=tablP.getValueAt(i, 0).toString();
            b=tablP.getValueAt(i, 1).toString();
            c=tablP.getValueAt(i, 2).toString();
            System.out.println(a+b+c);      
        ///////////////////////////////////////
        cell=new PdfPCell(new Phrase(a,FontFactory.getFont("Arial",11)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableP.addCell(cell);
         
         cell=new PdfPCell(new Phrase(b,FontFactory.getFont("Arial",11)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
           tableP.addCell(cell);
         
         cell=new PdfPCell(new Phrase(c,FontFactory.getFont("Arial",11)));
         cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableP.addCell(cell);
        }
         document.add(tableP);
            ////////////////////////////////////////////////////////
            document.add(new Paragraph(" "));
        document.add(new Paragraph("CLIENT"));
       document.add(new Paragraph(" "));
       ///
       PdfPTable tableC=new PdfPTable(6);
       tableP.setWidthPercentage(100);
         PdfPCell cellC;
        ///////////////////////////////////////////////////////////
        cellC=new PdfPCell(new Phrase("N*",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase("Nom",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase("Prenom",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase("Sexe",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
        
         cellC=new PdfPCell(new Phrase("Telephone",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase("Adresse",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         ///////////////////////////////////////////////
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 0).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 1).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 2).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         
         tableC.addCell(cellC);
        
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 5).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 3).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
        
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(tablC.getValueAt(0, 4).toString(),FontFactory.getFont("Arial",11)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         tableC.addCell(cellC);
         ////////////////////////////////////////
         cellC=new PdfPCell(new Phrase("",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(" ",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(" ",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(" ",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
        
         cellC=new PdfPCell(new Phrase("TOTAL",FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellC.setBackgroundColor(Color.GRAY);
         tableC.addCell(cellC);
         
         cellC=new PdfPCell(new Phrase(jTextTotal.getText().toString(),FontFactory.getFont("Georgia",12)));
         cellC.setHorizontalAlignment(Element.ALIGN_CENTER);

         tableC.addCell(cellC);
        
         document.add(tableC);
    document.close();
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Erreur " + e.getMessage(), "Alerte", JOptionPane.ERROR_MESSAGE);
       }    
    }

}
