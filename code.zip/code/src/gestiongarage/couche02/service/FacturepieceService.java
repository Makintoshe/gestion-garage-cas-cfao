/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.FacturepieceDao;
import gestiongarage.couche01_acces_donnees.entite.Client;
import gestiongarage.couche01_acces_donnees.entite.Facturepiece;
import gestiongarage.couche01_acces_donnees.entite.PieceRechange;
import java.time.LocalDate;

/**
 *
 * @author Ketsia
 */
public class FacturepieceService {
   private static Facturepiece ftpX=new Facturepiece();
   private static FacturepieceDao ftpDao=new FacturepieceDao();
   public static int AjouterF(PieceRechange codePiece,Client idClient,double prT, int qte){
       
        //
       ftpX.setCodePiece(codePiece);
       ftpX.setIdClient(idClient);
       ftpX.setPrT(prT);
       ftpX.setQte(qte);
       ftpX.setDateVentep(LocalDate.now());
       return ftpDao.Ajouter(ftpX);
   }
}
