/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage.couche02.service;

import gestiongarage.couche01_acces_donnees.dao.Type_AutomobileDao;
import gestiongarage.couche01_acces_donnees.entite.Type_automobile;

/**
 *
 * @author Laurel
 */
public class Type_autoService {

    private static Type_AutomobileDao typDao = new Type_AutomobileDao();
    private static Type_automobile typautX = new Type_automobile();

    public static int AjouterType(String designation) {
        typautX.setDesignation(designation);
        return typDao.Ajouter(typautX);
    }
}
