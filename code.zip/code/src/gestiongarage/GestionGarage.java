/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiongarage;

import gestiongarage.couche03_presentation.gui.GuiPrincipal;
import javax.swing.JOptionPane;

/**
 *
 * @author Ketsia
 */
public class GestionGarage {
    public static String username;
    public static String userpwd;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GuiPrincipal Open=new GuiPrincipal();
        username=JOptionPane.showInputDialog("Votre nom d'utilisateur");
        userpwd=JOptionPane.showInputDialog("Votre mot de passe");
        Open.setVisible(true);
    }
    
}
