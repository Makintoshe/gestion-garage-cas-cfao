-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 08 mai 2020 à 17:36
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bdgaragerep`
--

-- --------------------------------------------------------

--
-- Structure de la table `automobile`
--
-- Erreur de lecture de structure pour la table bdgaragerep.automobile : #1932 - Table 'bdgaragerep.automobile' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.automobile : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`automobile`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `categoriepiec`
--
-- Erreur de lecture de structure pour la table bdgaragerep.categoriepiec : #1932 - Table 'bdgaragerep.categoriepiec' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.categoriepiec : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`categoriepiec`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `client`
--
-- Erreur de lecture de structure pour la table bdgaragerep.client : #1932 - Table 'bdgaragerep.client' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.client : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`client`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `facturerep`
--
-- Erreur de lecture de structure pour la table bdgaragerep.facturerep : #1932 - Table 'bdgaragerep.facturerep' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.facturerep : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`facturerep`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `faturepiece`
--
-- Erreur de lecture de structure pour la table bdgaragerep.faturepiece : #1932 - Table 'bdgaragerep.faturepiece' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.faturepiece : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`faturepiece`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `mecanicien`
--
-- Erreur de lecture de structure pour la table bdgaragerep.mecanicien : #1932 - Table 'bdgaragerep.mecanicien' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.mecanicien : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`mecanicien`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `piecerechange`
--
-- Erreur de lecture de structure pour la table bdgaragerep.piecerechange : #1932 - Table 'bdgaragerep.piecerechange' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.piecerechange : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`piecerechange`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `reparation`
--
-- Erreur de lecture de structure pour la table bdgaragerep.reparation : #1932 - Table 'bdgaragerep.reparation' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.reparation : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`reparation`' à la ligne 1

-- --------------------------------------------------------

--
-- Structure de la table `type_automobile`
--
-- Erreur de lecture de structure pour la table bdgaragerep.type_automobile : #1932 - Table 'bdgaragerep.type_automobile' doesn't exist in engine
-- Erreur de lecture des données pour la table bdgaragerep.type_automobile : #1064 - Erreur de syntaxe près de 'FROM `bdgaragerep`.`type_automobile`' à la ligne 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
